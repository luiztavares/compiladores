varglob
	inteiro a = 2;
	decimal var;
bolgrav

texto minhaFuncao (decimal a, bool q, caractere m, < 3, 2 > inteiro matriz, < 4 > decimal vetor)
	ok
	inteiro var;
	decimal d;
	caractere v;
	;
	repita
		a = a + 1;
	ate u diferente 7;
	
	A = 123+ 3123123 - 782168479 em [13:123[;
para i em [5:32] incremente -2 :;
se 7 mod 2 igual 0 entao
	string = "se fudeu menache";
senao
	string  = "tabom c tava certo";
	
se i < temp entao ;
senao
	a = a + 1;
	
	
se 2 entao
	ok
	a = 8;
	b = 2 + 1;
	ko
senao
	ok
	
	c = verdadeiro;
	ko
	
enquanto 2 + 2 igual 5 :
ok
	string = "la na minha casa";
	string = "radiohead";
ko


repita 
ok
	a = a+1;
	b = b + 1;
ko
ate a < 0 ;	


a = {1,2,3};
b = {{}, {}, {}};	
	
	
minhaFuncao(2, 4, {2,3}, "texto", 'o', {{2, 4}, {2,3}}, 42);

a = leia();

escreva(2+ 4);
	ko


	
ok computer()
	a = 47;
	retorne ;
ko computer
